namespace Godot;

using Godot;
using System;
using System.Collections.Generic;
using System.Numerics; // Import System.Numerics for Matrix4x4

public partial class Karya2 : Node2D
{
  public override void _Ready()
  {
    base._Ready();
  }

  public override void _Draw()
  {
    base._Draw();
  }

  public override void _ExitTree()
  {
    base._ExitTree();
  }
}